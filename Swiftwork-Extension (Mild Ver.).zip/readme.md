# SwiftWork Sidebar Chrome Extension

## Overview


---

## Installation Guide

### 1. Download or Clone the Project
Download all project files (e.g., `manifest.json`, `content.js`, and any image/icon assets) into one folder. 
 
### 2. Open Chrome Extensions Page
1. Open Google Chrome  
2. Go to: `chrome://extensions/`  
3. Enable **Developer mode**

### 3. Load the Extension
1. Click **“Load unpacked”**  
2. Select your `swiftwork-extension/` folder  
3. The extension will appear in your list