(function () {
  const SIDEBAR_ID = "swiftwork-sidebar";
  const BACKDROP_ID = "swiftwork-backdrop";
  const SIDEBAR_WIDTH = 380;
  const iconPath = chrome.runtime.getURL("icons/Swiftwork-header.png");
  const collapsedIconPath = chrome.runtime.getURL("icons/Swiftwork-icon.png");

  // *** ข้อมูล Topics ควรมีรายละเอียดสำหรับหน้า Detail เพิ่มเติม ***
  const topics = [
      { 
          name: "ภาพปกงาน", 
          emoji: "🖼️", 
          score: 0, 
          status: "fail",
          selector: "div:has(> input[id='cover-image']) > div:first-child",
          details: {
              fail: [
                  "- อัปโหลดภาพคุณภาพสูง (1280x720px หรือ 16:9)",
                  "- ใช้ภาพที่สื่อถึงแบรนด์หรือสไตล์ที่เป็นตัวตนของคุณ",
                  "- หลีกเลี่ยงการใส่ข้อความมากเกินไปในรูปภาพ"
              ]
          }
      },
      { 
          name: "ชื่องาน", 
          emoji: "📝", 
          score: 80, 
          status: "pass",
          selector: "input[name='title']",
          details: {
              passTips: [
                  "- ทำให้ชื่อไม่เกิน 70 ตัวอักษร",
                  "- ใส่คีย์เวิร์ดหลักไว้ต้นชื่อ"
              ]
          }
      },
      { 
          name: "หมวดหมู่", 
          emoji: "🏷️", 
          score: 60, 
          status: "suggest",
          selector: "div:has(> input[name='subcategory']) > div:first-of-type",
          details: {
              current: "ออกแบบกราฟิก > สิ่งพิมพ์และนามบัตร",
              aiAnalysis: "หมวดหมู่ที่คุณเลือกไม่สอดคล้องกับประเภทงานบริการ รับจ้างทำโลโก้ อาจทำให้ลูกค้าค้นหาบริการของคุณไม่เจอ",
              suggestion: "ตรวจสอบและปรับหมวดหมู่ให้ตรงกับประเภทของงานคุณ",
              aiFix: "ออกแบบกราฟิก > Logo"
          }
      },
      { 
          name: "ราคาเริ่มต้น", 
          emoji: "💲", 
          score: 70, 
          status: "suggest",
          selector: "input[name='price']",
           details: {
              current: "1,000 บาท",
              aiAnalysis: "ราคาตั้งต้นอาจต่ำกว่าเรทตลาดเมื่อเทียบกับบริการ \"ออกแบบโลโก้ขั้นพื้นฐาน\" (≈ 2,500-5,000 บาท)",
              suggestion: "ปรับราคาเริ่มต้นให้อยู่ในช่วง 2,000-3,000 บาท หรือตั้งให้ใกล้เคียงกับคู่แข่ง",
              aiFix: "2,500 บาท"
          }
      },
      { 
          name: "เพิ่มการมองเห็นของการ์ดงาน", 
          emoji: "👁️", 
          score: 70, 
          status: "suggest",
          selector:  ".lo-12._g-16px > a:nth-of-type(1) .Style_card__sVrMp", 
      },
      { 
          name: "ข้อมูลแพ็กเกจ", 
          emoji: "📦", 
          score: 65, 
          status: "suggest",
          selector: ".lo-12._g-16px > a:nth-of-type(2) .Style_card__sVrMp", 
      },
      { 
          name: "อัลบั้มผลงาน", 
          emoji: "📚", 
          score: 80, 
          status: "pass",
          selector: ".lo-12._g-16px > a:nth-of-type(3) .Style_card__sVrMp", 
      }
  ];

  let currentHighlightTimer = null;
  let currentFilter = "all";
  let isCollapsed = false;
  // --- 💡 STEP 1: เพิ่มตัวแปร State ---
  // ถ้า currentTopic เป็น null = แสดงหน้ารวม
  // ถ้า currentTopic มีข้อมูล object = แสดงหน้ารายละเอียด
  let currentTopicIndex = -1; 
  let blockURLUpdate = false;

  const FILTERS = [
    { key: "all", color: "#0DA1FF", icon: "☰" },
    { key: "pass", color: "#00BF63", icon: "✔" },
    { key: "suggest", color: "#F9D746", icon: "!" },
    { key: "fail", color: "#F25849", icon: "✖" }
  ];

  // --- FIX: Detect URL change in SPA (Fastwork uses pushState) ---
  (function() {
      const originalPushState = history.pushState;
      const originalReplaceState = history.replaceState;

      function handleURLChange() {
          setCurrentTopicFromURL();
          renderSidebar();
      }

      history.pushState = function(...args) {
          originalPushState.apply(this, args);
          handleURLChange();
      };

      history.replaceState = function(...args) {
          originalReplaceState.apply(this, args);
          handleURLChange();
      };

      window.addEventListener("popstate", handleURLChange);
  })();


  function createSidebar() {
    if (document.getElementById(SIDEBAR_ID)) return;

    const useOverlay = window.innerWidth < 800;
    const sidebar = document.createElement("aside");
    sidebar.id = SIDEBAR_ID;
    sidebar.style.cssText = `
      position: fixed; top: 0; right: 0; height: 100%;
      width: ${SIDEBAR_WIDTH}px;
      background: #f7f9fc; 
      padding: 16px; 
      overflow-y: scroll;
      box-sizing: border-box; 
      z-index: 2147483647; 
      font-family: Arial, sans-serif;
      box-shadow: -3px 0 8px rgba(0,0,0,0.15);
      border-left: 1px solid #e0e0e0;
      transition: width 220ms ease;
    `;

    document.body.appendChild(sidebar);

    createHighlightElements();

    if (useOverlay) {
        const backdrop = document.createElement("div");
        backdrop.id = BACKDROP_ID;
        backdrop.style.cssText = "position:fixed;inset:0;background:rgba(0,0,0,0.35);z-index:2147483644";
        backdrop.addEventListener("click", closeSidebar);
        document.body.appendChild(backdrop);
    } else {
        const container = document.querySelector("#__next") || document.querySelector("main") || document.body;
        container.style.transition = "margin-right 220ms ease";
        container.style.marginRight = SIDEBAR_WIDTH + "px";
    }
  }

  function createHighlightElements() {
    // 🕳️ Overlay มืดที่เจาะรูโปร่งใสตรงกลาง
    if (!document.getElementById('swiftwork-dimmer-overlay')) {
      const dimmer = document.createElement('div');
      dimmer.id = 'swiftwork-dimmer-overlay';
      dimmer.style.cssText = `
        position: fixed;
        inset: 0;
        background: rgba(0, 0, 0, 0.6);
        z-index: 2147483645;
        display: none;
        pointer-events: none;
        transition: opacity 0.3s ease;
      `;
      document.body.appendChild(dimmer);
    }

    // 🔵 กรอบขอบน้ำเงิน
    if (!document.getElementById('swiftwork-highlighter-box')) {
      const highlighter = document.createElement('div');
      highlighter.id = 'swiftwork-highlighter-box';
      highlighter.style.cssText = `
        position: fixed;
        z-index: 2147483646;
        display: none;
        pointer-events: none;
        border: 3px solid #035db9;
        border-radius: 10px;
        box-shadow: 0 0 12px rgba(3, 93, 185, 0.6);
        background: transparent;
        transition: all 0.2s ease;
      `;
      document.body.appendChild(highlighter);
    }
  }

  function highlightElement(selector) {
    const el = document.querySelector(selector);
    const dimmer = document.getElementById('swiftwork-dimmer-overlay');
    const highlighter = document.getElementById('swiftwork-highlighter-box');
    if (!el || !dimmer || !highlighter) return;

    el.scrollIntoView({ behavior: 'smooth', block: 'center' });

    setTimeout(() => {
      const rect = el.getBoundingClientRect();
      const padding = 6;
      const top = rect.top - padding;
      const left = rect.left - padding;
      const width = rect.width + padding * 2;
      const height = rect.height + padding * 2;

      // 🔵 ปรับ highlighter ให้เป็นกรอบน้ำเงิน + เงามืดรอบๆ
      highlighter.style.top = `${top}px`;
      highlighter.style.left = `${left}px`;
      highlighter.style.width = `${width}px`;
      highlighter.style.height = `${height}px`;
      highlighter.style.display = 'block';
      highlighter.style.boxShadow = `
        0 0 0 9999px rgba(0,0,0,0.6)
      `;

      // ซ่อนหลัง 2.5 วิ
      setTimeout(() => {
        highlighter.style.display = 'none';
      }, 1500);
    }, 400);
  }

  function setCurrentTopicFromURL() {
    if (blockURLUpdate) return;
    const path = window.location.pathname;

    const pageTopicMap = {
        "/product/searchable-info": "เพิ่มการมองเห็นของการ์ดงาน",
        "/product/packages": "ข้อมูลแพ็กเกจ",
        "/product/album": "อัลบั้มผลงาน"
    };

    const topicName = pageTopicMap[path];
    if (topicName) {
        currentTopicIndex = topics.findIndex(t => t.name === topicName);
    } else {
        currentTopicIndex = -1; // หน้ารวม
    }
  }


  // --- 💡 STEP 2: ปรับแก้ renderSidebar ให้เป็น Router ---
  function renderSidebar() {
    const sidebar = document.getElementById(SIDEBAR_ID);
    if (!sidebar) return;
    
    // ถ้ามีหัวข้อถูกเลือก ให้แสดงหน้ารายละเอียดแทน แล้วจบการทำงาน
    if (currentTopicIndex > -1) {
        renderDetailView(currentTopicIndex);
        return;
    }

    // (โค้ดเดิม) ถ้าไม่มีหัวข้อถูกเลือก ก็แสดงหน้ารายการรวมปกติ
    const visibleTopics = currentFilter === "all" ? topics : topics.filter(t => t.status === currentFilter);

    sidebar.innerHTML = `
      <header style="margin-bottom:8px; height:50px;">
        <div style="display:flex;align-items:center;justify-content:space-between;
                    background:#035db9;padding:0 12px;border-radius:8px;color:white;
                    height:100%;">
          <img src="${iconPath}" alt="SwiftWork" style="height:24px;object-fit:contain;">
          <div style="margin-left:auto; display:flex; gap:8px;">
            <button id="collapseSidebar" style="background:none;border:none;color:white;font-size:35px;cursor:pointer;margin-top:-6px;">-</button>
            <button id="closeSidebar" style="background:none;border:none;color:white;font-size:18px;cursor:pointer;">✖</button>
          </div>
        </div>
      </header>

      <section style="display:flex;align-items:center;background:#e6f0ff;padding:16px;border-radius:12px;margin-bottom:16px;">
        <div style="flex:1;">
          <div style="font-weight:bold;font-size:16px;color:#035db9;">ยกระดับประกาศงานของคุณ!</div>
          <div style="font-size:11px;color:#555;margin-top:4px;">ปรับปรุงประกาศของคุณให้ดียิ่งขึ้น เพื่อดึงดูดลูกค้าและเพิ่มโอกาสในการขายมากกว่าเดิม</div>
        </div>
        <div style="width:80px;height:80px;position:relative;">
          <svg viewBox="0 0 36 36" style="transform: rotate(-90deg); width:100%; height:100%;">
            <path d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none" stroke="#ddd" stroke-width="3.5"/>
            <path id="progress-circle" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                  fill="none" stroke="#ffb74d" stroke-width="3.5" stroke-dasharray="0,100" stroke-linecap="round"/>
          </svg>
          <div style="position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);text-align:center;">
            <div style="font-size:12px;font-weight:bold;">🔥</div>
            <div style="font-size:14px;font-weight:bold;" id="score-number">85</div>
            <div style="font-size:10px;color:#555;">คะเเนน</div>
          </div>
        </div>
      </section>

      <div style="display:flex;gap:16px;justify-content:flex-start;margin-bottom:16px;padding-left:12px">
        ${FILTERS.map(f => {
          const isActive = f.key === currentFilter;
          return `
            <button data-status="${f.key}" title="${f.key.toUpperCase()}"
              style="
                width:40px;height:40px;border-radius:50%;
                background:${f.color};color:white;font-size:18px;
                display:flex;align-items:center;justify-content:center;
                border:none;cursor:pointer;transition:all 0.2s ease;
                ${isActive ? `box-shadow:0 0 6px rgba(0,0,0,0.20), 0 0 0 3px ${f.color};` : ""}
              ">
              ${f.icon}
            </button>
          `;
        }).join("")}
      </div>

      <section style="display:flex;flex-direction:column;gap:12px;">
        ${
          visibleTopics.length > 0 
          ? visibleTopics.map(t => `
              <div class="topic-card" data-topic-name="${t.name}" style="display:flex;align-items:center;justify-content:space-between;background:white;padding:12px;border-radius:10px;box-shadow:0 1px 3px rgba(0,0,0,0.1); cursor:pointer; transition: transform 0.2s ease;">
                <div style="display:flex;align-items:center;gap:10px">
                  <span style="font-size:18px">${t.emoji}</span>
                  <span>${t.name}</span>
                </div>
                <div style="display:flex;align-items:center;gap:6px">
                  <span style="font-size:13px;color:#666;">${t.score}</span>
                  ${statusIcon(t.status)}
                </div>
              </div>
            `).join("")
          : `... (โค้ดส่วนของการ์ดว่างเปล่า) ...`
        }
      </section>

      ${currentFilter === "all" ? `
      <section style="background:#fff4e5;padding:12px;border-radius:12px;margin-top:16px; box-shadow:0 1px 3px rgba(0,0,0,0.1)">
        <div style="font-weight:bold;color:#ff9800;margin-bottom:6px;">💡 คำแนะนำ</div>
        <div style="font-size:12px;color:#555;">
          ควรได้อย่างน้อย <b>80</b> คะแนนในแต่ละหมวด เพื่อเพิ่มคะแนนรวมของประกาศ แนะนำให้ปรับปรุงหมวดที่ได้คะแนนต่ำก่อน
        </div>
      </section>` : ""}

      <div style="display:flex;justify-content:flex-end;margin-top:8px;">
        <button id="regenBtn" style="background:#035db9;color:white;padding:8px 16px;border:none;border-radius:6px;cursor:pointer;font-size:15px;">🔧 วิเคราะห์ใหม่</button>
      </div>
    `;

    const totalScore = Math.round(topics.reduce((a,b)=>a+b.score,0)/topics.length);
    updateOverallScore(totalScore);

    // --- 💡 STEP 4: เพิ่ม Event Listener ให้กับการ์ด ---
    document.querySelectorAll(".topic-card").forEach(card => {
        card.addEventListener("click", () => {
            const topicName = card.dataset.topicName;
            const selectedIndex = topics.findIndex(t => t.name === topicName);
            if (selectedIndex > -1) {
                currentTopicIndex = selectedIndex;
                renderSidebar();
            }
        });
        card.addEventListener('mouseenter', () => card.style.transform = 'scale(1.02)');
        card.addEventListener('mouseleave', () => card.style.transform = 'scale(1)');
    });

    document.getElementById("closeSidebar").addEventListener("click", closeSidebar);
    document.getElementById("regenBtn").addEventListener("click", () => alert("Regenerate clicked"));
    document.getElementById("collapseSidebar").addEventListener("click", toggleCollapse);
    sidebar.querySelectorAll("button[data-status]").forEach(btn => {
        btn.addEventListener("click", () => {
            currentFilter = btn.getAttribute("data-status");
            renderSidebar();
        });
        btn.addEventListener('mouseenter', () => btn.style.transform = 'scale(1.15)');
        btn.addEventListener('mouseleave', () => btn.style.transform = 'scale(1)');
    });
  }

  // ตรวจว่าอยู่หน้าที่ถูกต้องไหม
  function isCorrectPage(topic) {
      const restrictedTopics = [
          "เพิ่มการมองเห็นของการ์ดงาน",
          "ข้อมูลแพ็กเกจ",
          "อัลบั้มผลงาน"
      ];

      const pageTopicMap = {
        "/product/searchable-info": "เพิ่มการมองเห็นของการ์ดงาน",
        "/product/packages": "ข้อมูลแพ็กเกจ",
        "/product/album": "อัลบั้มผลงาน"
      };

      const path = window.location.pathname;

      const isSpecificPage = Object.prototype.hasOwnProperty.call(pageTopicMap, path);

      if (isSpecificPage) {
        // แสดงได้ก็ต่อเมื่อ topic ตรงกับหน้าปัจจุบันเท่านั้น
        return pageTopicMap[path] === topic.name;
      }

      return !restrictedTopics.includes(topic.name);
  }

  // --- 💡 STEP 3: สร้างฟังก์ชัน renderDetailView ---
  function renderDetailView(index) {
    const topic = topics[index]; // ดึง topic จริงจาก index
    const sidebar = document.getElementById(SIDEBAR_ID);
    if (!sidebar || !topic) return;

    if (!isCorrectPage(topic)) {
      if (topic.selector) highlightElement(topic.selector);
      sidebar.innerHTML = `
          <header style="margin-bottom:8px; height:50px;">
            <div style="display:flex;align-items:center;justify-content:space-between;
                        background:#035db9;padding:0 12px;border-radius:8px;color:white;
                        height:100%;">
              <button id="back-to-list-btn" style="background: none; border: none; color: white; font-size: 16px; cursor: pointer; display: flex; align-items: center; gap: 8px;">
              <span style="font-size: 20px;">‹</span> ย้อนกลับ
              </button>
              <div style="margin-left:auto; display:flex; gap:8px;">
                <button id="collapseSidebar" style="background:none;border:none;color:white;font-size:35px;cursor:pointer;margin-top:-6px;">-</button>
                <button id="closeSidebar" style="background:none;border:none;color:white;font-size:18px;cursor:pointer;">✖</button>
              </div>
            </div>
          </header>

          <div id="detail-content-wrapper" style="background: #F7F9FC;padding: 16px;">

              <!-- ส่วนหัวข้อเดิม -->
              <div style="
                  display: flex; justify-content: space-between; align-items: center;
                  background: #E6F0FF; padding: 12px; border-radius: 12px;
                  box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin: -16px -16px 16px -16px;">
                  
                  <button id="prev-topic-btn" style="background: #dce7f9ff; border: none; width: 32px; height: 32px; border-radius: 50%; font-size: 20px; cursor: pointer; color: #495057;">‹</button>

                  <div style="text-align: center;">
                      <div style="font-weight: bold; margin-bottom: 4px;">
                          <div style="font-size: 40px; line-height: 1;">${topic.emoji}</div>
                          <div style="font-size: 16px; margin-top: 12px;">${topic.name}</div>
                      </div>
                      <div style="font-size: 13px; color: #6c757d;
                                  display: inline-flex; align-items: center; gap: 6px;
                                  background: white; padding: 4px 10px; border-radius: 16px;
                                  box-shadow: 0 1px 4px rgba(0,0,0,0.1);">
                          คะแนน: ไม่สามารถแสดง
                          <div style="
                              width:12px; height:12px; border-radius:50%; font-size:12px;
                              display:flex; align-items:center; justify-content:center;">⚠️</div>
                      </div>
                  </div>

                  <button id="next-topic-btn"
                          style="background: #dce7f9ff; border: none; width: 32px;
                          height: 32px; border-radius: 50%; font-size: 20px;
                          cursor: pointer; color: #495057;">›</button>
              </div>

              <!-- ข้อความเตือนแทน detailContent -->
              <div style="text-align:center;padding:20px;">
                  <div style="font-size:40px;margin-bottom:12px;">⚠️</div>
                  <div style="margin: 0 0 8px 0; color: #333; font-size: 16px; font-weight: bold;"> ไม่สามารถแสดงข้อมูล</div>
                  <p style="margin: 0; font-size: 13px; color: #555;">
                      หัวข้อ <b>${topic.name}</b> ไม่ได้อยู่ในหน้าที่เกี่ยวข้อง กรุณาไปยังหน้าที่ถูกต้องเพื่อดูรายละเอียด
                  </p>
              </div>

          </div>
      `;

      // ปุ่มกลับ
      document.getElementById("back-to-list-btn").onclick = () => {
          blockURLUpdate = true;    
          currentTopicIndex = -1;
          renderSidebar();

          setTimeout(() => blockURLUpdate = false, 50);
      };

      document.getElementById("prev-topic-btn").addEventListener("click", () => {
          currentTopicIndex = (index - 1 + topics.length) % topics.length;
          renderSidebar();
      });

      document.getElementById("next-topic-btn").addEventListener("click", () => {
          currentTopicIndex = (index + 1) % topics.length;
          renderSidebar();
      });

      document.getElementById("closeSidebar").addEventListener("click", closeSidebar);
      document.getElementById("collapseSidebar").addEventListener("click", toggleCollapse);
      return;
  }


    if (topic.selector) {
      highlightElement(topic.selector);
    }

    let detailContent = '';

    const getStatusIconAndColor = (status) => {
        if (status === 'fail') return { icon: '✖', color: '#F25849'};
        if (status === 'suggest') return { icon: '!', color: '#F9D746' };
        return { icon: '✔', color: '#00BF63' }; 
    }
    const { icon: statusIconChar, color: statusColor } = getStatusIconAndColor(topic.status);

    // สร้างเนื้อหาตาม status ของ topic
    switch(topic.status) {
        case 'pass':
            detailContent = `
                <div style="text-align: center; padding: 20px;">
                    <div style="width: 50px; height: 50px; border-radius: 50%; background-color: #00BF63; color: white; font-size: 25px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 16px;">✔</div>
                    <div style="margin: 0 0 8px 0; color: #333; font-size: 16px; font-weight: bold;">ดีมาก!</div>
                    <p style="margin: 0; font-size: 13px; color: #555;">${topic.name} ของคุณยอดเยี่ยมและเป็นไปตามแนวทางปฏิบัติที่ดีแล้ว</p>
                </div>
                ${topic.details?.passTips ? `
                <div style="background-color: #fff4e5; border-radius: 8px; padding: 16px; margin-top: -10px; margin-left: -16px; margin-right: -16px; box-shadow:0 1px 3px rgba(0,0,0,0.1)">
                    <div style="margin: 0 0 8px 0; color: #ff9800; font-size: 14px; font-weight: bold;">💡 เคล็ดลับเพิ่มเติม:</div>
                    <ul style="margin: 0; padding-left: 20px; font-size: 13px; color: #555; line-height: 1.6;">
                        ${topic.details.passTips.map(tip => `<li>${tip}</li>`).join('')}
                    </ul>
                </div>` : ''}
            `;
            break;
        case 'suggest':
            detailContent = `
                <div style="background: white; border-radius: 12px; padding: 16px; margin-bottom: 12px; margin-left: -16px; margin-right: -16px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <div style="font-size: 14px; color: #888;">ปัจจุบัน:</div>
                    <div style="font-size: 13px; color: #333; margin-top: 4px;">${topic.details?.current || 'N/A'}</div>
                </div>

                <div style="background: #E6F0FF; border-radius: 12px; padding: 16px; margin-bottom: 12px; margin-left: -16px; margin-right: -16px; box-shadow:0 1px 3px rgba(0,0,0,0.1);">
                    <div style="font-weight: bold; font-size: 14px; color: #035DB9; margin-bottom: 8px;">การวิเคราะห์โดย SwiftWork AI</div>
                    <p style="font-size: 13px; color: #555; margin: 0;">${topic.details?.aiAnalysis || 'ไม่มีข้อมูลวิเคราะห์'}</p>
                </div>

                <div style="background: #fff4e5; border-radius: 12px; padding: 16px; margin-bottom: 12px; margin-left: -16px; margin-right: -16px; box-shadow:0 1px 3px rgba(0,0,0,0.1)">
                    <div style="font-weight: bold; font-size: 14px; color: #ff9800; margin-bottom: 8px;">💡 คำแนะนำ:</div>
                    <p style="font-size: 13px; color: #555; margin: 0;">${topic.details?.suggestion || 'ไม่มีคำแนะนำ'}</p>
                </div>

                <div style="background: white; border-radius: 12px; padding: 16px; box-shadow:0 1px 3px rgba(0,0,0,0.1); margin-left: -16px; margin-right: -16px;">
                    <div style="font-weight: bold; font-size: 14px; color: #035DB9; margin-bottom: 12px;">✨ แก้ไขโดย SwiftWork AI</div>
                    <div style="background: #E6F0FF; padding: 13px; border-radius: 8px; font-size: 13px; color: #333;">${topic.details?.aiFix || 'N/A'}</div>
                </div>
            `;
            break;
        case 'fail':
            detailContent = `
                 <div style="text-align: center; padding: 20px;">
                    <div style="width: 50px; height: 50px; border-radius: 50%; background-color: #F25849; color: white; font-size: 25px; display: inline-flex; align-items: center; justify-content: center; margin-bottom: 16px;">✖</div>
                    <div style="margin: 0 0 8px 0; color: #333; font-size: 16px; font-weight: bold;">ยังไม่มี!</div>
                    <p style="margin: 0; font-size: 13px; color: #555;">${topic.name} ผลงานของคุณยังไม่ได้ใส่ อาจทำให้ไม่ได้รับการมองเห็น</p>
                </div>
                <div style="background-color: #ffebee; border-radius: 8px; padding: 16px; margin-top: -10px; margin-left: -16px; margin-right: -16px; box-shadow:0 1px 3px rgba(0,0,0,0.1)">
                    <div style="margin: 0 0 12px 0; color: #F25849; font-size: 14px; font-weight: bold;">🚨 ขั้นตอนถัดไป:</div>
                    <ul style="margin: 0; padding-left: 20px; font-size: 13px; color: #555; line-height: 1.6;">
                         ${(topic.details?.fail || ['ไม่มีข้อมูล']).map(item => `<li>${item}</li>`).join('')}
                    </ul>
                </div>
            `;
            break;
    }

    // โครงสร้างหลักของหน้ารายละเอียด
    sidebar.innerHTML = `
        <header style="margin-bottom:8px; height:50px;">
          <div style="display:flex;align-items:center;justify-content:space-between;
                      background:#035db9;padding:0 12px;border-radius:8px;color:white;
                      height:100%;">
            <button id="back-to-list-btn" style="background: none; border: none; color: white; font-size: 16px; cursor: pointer; display: flex; align-items: center; gap: 8px;">
            <span style="font-size: 20px;">‹</span> ย้อนกลับ
            </button>
            <div style="margin-left:auto; display:flex; gap:8px;">
              <button id="collapseSidebar" style="background:none;border:none;color:white;font-size:35px;cursor:pointer;margin-top:-6px;">-</button>
              <button id="closeSidebar" style="background:none;border:none;color:white;font-size:18px;cursor:pointer;">✖</button>
            </div>
          </div>
        </header>
        
        <div id="detail-content-wrapper" style="background: #F7F9FC;padding: 16px;">
    
           <div style="display: flex; justify-content: space-between; align-items: center; background: #E6F0FF; padding: 12px; border-radius: 12px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin: -16px -16px 16px -16px;">
              <button id="prev-topic-btn" style="background: #dce7f9ff; border: none; width: 32px; height: 32px; border-radius: 50%; font-size: 20px; cursor: pointer; color: #495057;">‹</button>
              <div style="text-align: center;">
                  <div style="text-align: center; font-weight: bold; margin-bottom: 4px;">
                    <div style="font-size: 40px; line-height: 1;">${topic.emoji}</div>
                    <div style="font-size: 16px; margin-top: 12px;">${topic.name}</div>
                  </div>

                  <div style="font-size: 13px; color: #6c757d; display: inline-flex; align-items: center; gap: 6px; background: white; padding: 4px 10px; border-radius: 16px; box-shadow: 0 1px 4px rgba(0,0,0,0.1);margin-top: 4px;">
                      คะแนน: ${topic.score}
                      <div style="width:12px; height:12px; border-radius:50%; background:${statusColor}; color:white; font-size:8px; display:flex; align-items:center; justify-content:center;">${statusIconChar}</div>
                  </div>
              </div>
              <button id="next-topic-btn" style="background: #dce7f9ff; border: none; width: 32px; height: 32px; border-radius: 50%; font-size: 20px; cursor: pointer; color: #495057;">›</button>
          </div>

          ${detailContent}

          <div style="margin-top: 24px;">
              ${topic.status === 'suggest' ? `
                  <div style="display: flex; gap: 10px;">
                      <button id="applySuggestionBtn" style="flex: 1; background: #FF9F00; color: white; border: none; padding:8px 16px; border-radius: 6px; cursor: pointer; font-size: 15px; font-weight: bold;">ใช้คำแนะนำนี้</button>
                      <button style="flex: 1; background: #035DB9; color: white; border: none; padding:8px 16px; border-radius: 6px; cursor: pointer; font-size: 15px; font-weight: bold;">วิเคราะห์ใหม่</button>
                  </div>
              ` : `
                  <div style="display: flex; justify-content: flex-end;">
                    <button style="background: #035db9; color: white; border: none; padding:8px 16px; border-radius: 6px; cursor: pointer; font-size: 15px; font-weight: bold;">วิเคราะห์ใหม่</button>
                  </div>
              `}
          </div>
        </div>
      `;

    // --- 💡 STEP 4 (ต่อ): เพิ่ม Event Listener ให้ปุ่มย้อนกลับ ---
    document.getElementById("back-to-list-btn").addEventListener("click", () => {
      blockURLUpdate = true;     
      currentTopicIndex = -1;
      renderSidebar();

      setTimeout(() => blockURLUpdate = false, 50);
    });

    const collapseBtn = document.getElementById("collapseSidebar");
    if(collapseBtn) collapseBtn.addEventListener("click", toggleCollapse);

    const closeBtn = document.getElementById("closeSidebar");
    if(closeBtn) closeBtn.addEventListener("click", closeSidebar);

    document.getElementById("prev-topic-btn").addEventListener("click", () => {
    // เลื่อนไปหัวข้อด้านซ้าย (วนลูป)
      currentTopicIndex = (currentTopicIndex - 1 + topics.length) % topics.length;
      renderSidebar();
    });

    document.getElementById("next-topic-btn").addEventListener("click", () => {
        // เลื่อนไปหัวข้อด้านขวา (วนลูป)
      currentTopicIndex = (currentTopicIndex + 1) % topics.length;
      renderSidebar();
    });

    // 💡 เมื่อกดปุ่ม "ใช้คำแนะนำนี้"
    const applyBtn = document.getElementById("applySuggestionBtn");
    if (applyBtn) {
      applyBtn.addEventListener("click", () => {
        const targetSelector = topic.selector;
        const aiSuggestion = topic.details?.aiFix;

        if (!targetSelector || !aiSuggestion) {
          alert("ไม่พบตำแหน่งช่องกรอกหรือไม่มีคำแนะนำจาก AI");
          return;
        }

        const inputEl = document.querySelector(targetSelector);
        if (inputEl) {
          // ถ้าเป็น input / textarea → ใส่ค่าโดยตรง
          const realInput = inputEl.querySelector("input, textarea") || inputEl;
          realInput.value = aiSuggestion;
          realInput.dispatchEvent(new Event("input", { bubbles: true })); // แจ้ง React ว่ามีการเปลี่ยนค่า

          realInput.style.backgroundColor = "#e3f2fd"; // ฟ้าอ่อน
          realInput.style.transition = "background-color 0.3s ease";
        }
      });
    }

  }

  function statusIcon(status) {
    if (status === "pass") return `<div style="width:15px;height:15px;border-radius:50%;background:#00BF63;color:white;font-size:9px;display:flex;align-items:center;justify-content:center;">✔</div>`;
    if (status === "suggest") return `<div style="width:15px;height:15px;border-radius:50%;background:#F9D746;color:white;font-size:9px;display:flex;align-items:center;justify-content:center;">!</div>`;
    if (status === "fail") return `<div style="width:15px;height:15px;border-radius:50%;background:#F25849;color:white;font-size:9px;display:flex;align-items:center;justify-content:center;">✖</div>`;
    return "";
  }

  function closeSidebar(){
    const sidebar = document.getElementById(SIDEBAR_ID);
    if(sidebar) sidebar.remove();
    const bd = document.getElementById(BACKDROP_ID);
    if(bd) bd.remove();
    const container = document.querySelector("#__next") || document.querySelector("main") || document.body;
    container.style.marginRight = "";
  }

  function updateOverallScore(score) {
    const circle = document.getElementById("progress-circle");
    const number = document.getElementById("score-number");
    if (!circle || !number) return;

    const radius = 15.9155;
    const circumference = 2 * Math.PI * radius;
    const progress = (score / 100) * circumference;

    circle.setAttribute("stroke-dasharray", `${progress}, ${circumference}`);
    number.innerText = score;
  }

  function toggleCollapse() {
    // ... โค้ดส่วน toggleCollapse เดิม ไม่ต้องแก้ไข ...
    const sidebar = document.getElementById(SIDEBAR_ID);
    const container = document.querySelector("#__next") || document.querySelector("main") || document.body;
    if (!sidebar || !container) return;

    isCollapsed = !isCollapsed;

    if (isCollapsed) {
        sidebar.style.width = "60px";
        sidebar.style.background = "transparent";
        sidebar.style.padding = "0";
        sidebar.style.overflow = "visible";
        sidebar.style.borderLeft = "none";
        sidebar.style.boxShadow = "none";

        const container = document.querySelector("#__next") || document.querySelector("main") || document.body;
        container.style.marginRight = "0";

        sidebar.innerHTML = `
        <div style="display:flex;align-items:center;justify-content:center;height:100%;">
          <div style="
            background:#035db9;
            width:50px; 
            height:50px;
            display:flex;
            align-items:center;
            justify-content:center;
            border-radius:12px;
            cursor:pointer;
            box-shadow: 0 4px 6px rgba(0,0,0,0.3), 0 1px 3px rgba(0,0,0,0.2);
            transition: all 0.2s ease;
          " id="sidebarIconCollapsed" title="คลิกเพื่อขยาย">
            <img src="${collapsedIconPath}" style="width:30px;height:30px;">
          </div>
        </div>
        `;
        document.getElementById("sidebarIconCollapsed").addEventListener("click", toggleCollapse);
    } else {
        sidebar.style.width = SIDEBAR_WIDTH + "px";
        sidebar.style.background = "#f7f9fc";
        sidebar.style.padding = "16px";
        sidebar.style.overflowY = "scroll";
        sidebar.style.borderLeft = "1px solid #e0e0e0";
        sidebar.style.boxShadow = "-3px 0 8px rgba(0,0,0,0.15)";
        
        const container = document.querySelector("#__next") || document.querySelector("main") || document.body;
        if (window.innerWidth >= 800) {
            container.style.marginRight = SIDEBAR_WIDTH + "px";
        }
        
        currentTopicIndex = -1;
        renderSidebar();
    }
  }
  
  createSidebar();
  setCurrentTopicFromURL(); 
  renderSidebar();   
  
  // --- STEP 5: Detect URL change (SPA / Back button / Internal link) ---
  let lastPath = location.pathname;

  // ฟังก์ชันอัปเดต sidebar
  function checkURLChange() {
      if (location.pathname !== lastPath) {
          lastPath = location.pathname;

          // reset highlight
          const highlighter = document.getElementById('swiftwork-highlighter-box');
          if (highlighter) highlighter.style.display = 'none';

          setCurrentTopicFromURL();
          renderSidebar();
      }
  }

  // Hook history.pushState / replaceState
  (function() {
      const pushState = history.pushState;
      const replaceState = history.replaceState;

      history.pushState = function(...args) {
          const result = pushState.apply(this, args);
          checkURLChange();
          return result;
      };

      history.replaceState = function(...args) {
          const result = replaceState.apply(this, args);
          checkURLChange();
          return result;
      };
  })();

  // ปุ่ม browser back/forward
  window.addEventListener('popstate', checkURLChange);

  // ทุก internal link click
  document.addEventListener('click', e => {
      const link = e.target.closest('a');
      if (link && link.href && link.origin === location.origin) {
          setTimeout(checkURLChange, 50); // ให้ URL update ก่อน
      }
  });

  // Polling ทุก 300ms (ครอบคลุมทุกกรณี)
  setInterval(checkURLChange, 300);
  const targetNode = document.querySelector('main'); // เปลี่ยนเป็น container จริงของ Fastwork

  if (targetNode) {
      const observer = new MutationObserver((mutationsList, observer) => {
          for (const mutation of mutationsList) {
              if (mutation.type === 'childList' || mutation.type === 'subtree') {
                  // หน้าเปลี่ยน content → update sidebar
                  setCurrentTopicFromURL();
                  renderSidebar();
                  break;
              }
          }
      });

      observer.observe(targetNode, { childList: true, subtree: true });

  }

})();