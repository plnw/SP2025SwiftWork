// กดไอคอน Chrome → inject sidebar
chrome.action.onClicked.addListener((tab) => {
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["injectSidebar.js"]
  });
});

// Listener รับ message จาก content.js
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "analyzeProduct") {
    // ตัวอย่าง mock response
    const data = message.payload;
    const response = {
      scores: {
        title: data.title ? 90 : 0,
        description: data.description ? 85 : 0,
        price: data.price ? "OK" : "Missing"
      },
      suggestions: ["เพิ่ม keyword 'freelance'", "ปรับราคาสมเหตุสมผล"]
    };
    sendResponse(response);
  }
  return true; // ถ้าใช้ async
});
