console.log("SwiftWork content.js loaded ✅");

// ฟังก์ชันดึงข้อมูลจากฟอร์ม
function getFormData() {
  const title = document.querySelector('input[name="title"]')?.value || "";
  const price = document.querySelector('input[name="price"]')?.value || "";
  const description = document.querySelector('textarea[name="description"]')?.value || "";
  const categoryText = document.querySelector('.css-1dimb5e-singleValue')?.innerText || "";

  let category = categoryText.startsWith("ออกแบบกราฟิก") ? categoryText : "ไม่ใช่หมวดออกแบบกราฟิก";

  return { title, price, description, category };
}

// ฟังก์ชัน update sidebar
function updateSidebar(response) {
  document.getElementById("title-score").innerText = response.scores.title;
  document.getElementById("desc-score").innerText = response.scores.description;
  document.getElementById("price-check").innerText = response.scores.price;
  const ul = document.getElementById("suggestions-list");
  ul.innerHTML = response.suggestions.map(s => `<li>${s}</li>`).join("");
}

// ฟัง input/textarea/select changes
const inputs = document.querySelectorAll("input, textarea, select");
inputs.forEach(input => {
  input.addEventListener("input", () => {
    const data = getFormData();
    chrome.runtime.sendMessage({ action: "analyzeProduct", payload: data }, (response) => {
      if (response) updateSidebar(response);
    });
  });
});

// ปุ่ม Analyze Again
document.addEventListener("click", (e) => {
  if (e.target && e.target.id === "analyzeBtn") {
    const data = getFormData();
    chrome.runtime.sendMessage({ action: "analyzeProduct", payload: data }, (response) => {
      if (response) updateSidebar(response);
    });
  }
});
